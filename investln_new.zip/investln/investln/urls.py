from django.urls import include, path
from django.contrib import admin
from dashboard import views as dashboard
from pay import views as pay
from . import views as index


urlpatterns = [
    path('', index.index, name='home'),
    path('pricing/', pay.pricing, name='pricing'),
    path('Administrator/Dashboard/', admin.site.urls),
    path('account/', include('account.urls')),
    path('pay/', include('pay.urls')),
    # txt
    path('ads.txt', index.AdsView),
    path('Ads.txt', index.AdsView),
    path('robots.txt', index.RobotView),
    path('sitemap.txt', dashboard.SitemapView),
    #  Dashboard
    path('valuation/', dashboard.valuation, name='valuation'),
    path('revenue/', dashboard.revenue, name='revenue'),
    path('eps/', dashboard.eps, name='eps'),
    path('bvps/', dashboard.bvps, name='bvps'),
    path('debt/', dashboard.debt, name='debt'),
    path('dividend/', dashboard.dividend, name='dividend'),
]
