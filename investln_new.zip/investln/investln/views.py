from django.shortcuts import render
from django.http import HttpResponse

def index(request):
    return render(request, 'index.html')

def AdsView(request):
    lines = [
        "google.com, pub-7949183462389820, DIRECT, f08c47fec0942fa0",
        "google.com, pub-2305359031197990, DIRECT, f08c47fec0942fa0",
        "google.com, pub-6966735019331824, DIRECT, f08c47fec0942fa0",
        "smartadserver.com, 1328, RESELLER",
        "contextweb.com, 560288, RESELLER, 89ff185a4c4e857c",
        "pubmatic.com, 156439, RESELLER",
        "pubmatic.com, 154037, RESELLER",
        "pubmatic.com, 156030, RESELLER, 5d62403b186f2ace",
        "rubiconproject.com, 16114, RESELLER, 0bfd66d529a55807",
        "rubiconproject.com, 13132, RESELLER, 0bfd66d529a55807",
        "openx.com, 537149888, RESELLER, 6a698e2ec38604c6",
        "sovrn.com, 257611, RESELLER, fafdf38b16bf6b2b",
        "appnexus.com, 3703, RESELLER, f5ab79cb980f11d1",
        "groundtruth.com, 107, RESELLER, 81cbf0a75a5e0e9a",
        "districtm.io, 101760, RESELLER, 3fd707be9c4527c3",
    ]
    return HttpResponse("\n".join(lines), content_type="text/plain")

def RobotView(request):
    lines = [
        "User-Agent: *",
        "Allow: /",
    ]
    return HttpResponse("\n".join(lines), content_type="text/plain")