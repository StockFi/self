from django.urls import path
from . import views

urlpatterns = [
    path('subscription/pro/create/', views.pro_subscription_create, name='pro_subscription_create'),
    path('subscription/pro_plus/create/', views.pro_plus_subscription_create, name='pro_plus_subscription_create'),
    path('subscription/cancel/', views.subscription_cancel, name='subscription_cancel'),
    path('subscription/verify/', views.subscription_verify, name='subscription_verify'),

]