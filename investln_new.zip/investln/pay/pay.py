import requests
from datetime import datetime, timezone, timedelta

def get_token():
    url = 'https://api-m.sandbox.paypal.com/v1/oauth2/token'
    data = {'grant_type': 'client_credentials'}
    auth = ('AdfomsmYWJfK1Enj6Rs68pYXuQGBqmxNpEq_n0iWCc6zg28WpjFT6KOHxVdNjl-pY8eI2mDQnxD3IJqk',
            'EBKcIKpNTWghqCK49zWUNd7_3hazjMuHmeA496wPcBBAj3t32DHT7Nic257saXeRCI3HBUaw-ElVM-iD'
            )
    response = requests.post(url, data=data, auth=auth).json()['access_token']

    return response


def get_list_plans():
    url = 'https://api-m.sandbox.paypal.com/v1/billing/plans'
    headers = {
        'Authorization': 'Bearer ' + get_token(),
        'Content-Type': 'application/json',
    }
    params = (
        ('sort_by', 'create_time'),
        ('sort_order', 'desc'),
    )
    response = requests.get(url, headers=headers, params=params).json()

    return response


def get_plan_details(plan_id):
    url = f'https://api-m.sandbox.paypal.com/v1/billing/plans/{plan_id}'
    headers = {'Authorization': 'Bearer ' + get_token(),
               'Content-Type': 'application/json',
               }
    response = requests.get(url, headers=headers).json()

    return response


def get_subscription_details(subscription_id):
    url = f'https://api-m.sandbox.paypal.com/v1/billing/subscriptions/{subscription_id}'
    headers = {'Authorization': 'Bearer ' + get_token(),
               'Content-Type': 'application/json',
               }
    response = requests.get(url, headers=headers).json()

    return response


def create_subscription(email, plan_id):
    url = 'https://api-m.sandbox.paypal.com/v1/billing/subscriptions'
    headers = {
        'Authorization': 'Bearer ' + get_token(),
        'Content-Type': 'application/json',
        'PayPal-Request-Id': 'SUBSCRIPTION-TEST-001',
        'Prefer': 'return=representation',
    }
    
    t = (datetime.now(timezone(timedelta(hours=+0))) + timedelta(minutes=10)).isoformat(timespec="seconds").split('+')[0] + "Z"
    data = """{
            "plan_id": "PlanId",
            "start_time": "TimeStart",
            "quantity": "1",
            "shipping_amount": {
                "currency_code": "TWD",
                "value": "0"
            },
            "subscriber": {
                "name": {
                    "given_name": "",
                    "surname": ""
                },
                "email_address": "Email",
                "shipping_address": {
                    "name": {
                        "full_name": ""
                    },
                    "address": {
                        "address_line_1": "",
                        "address_line_2": "",
                        "admin_area_2": "",
                        "admin_area_1": "",
                        "postal_code": "",
                        "country_code": "TW"
                    }
                }
            },
            "application_context": {
                "brand_name": "INVESTLN 關連投資",
                "locale": "zh-TW",
                "shipping_preference": "SET_PROVIDED_ADDRESS",
                "user_action": "SUBSCRIBE_NOW",
                "payment_method": {
                    "payer_selected": "PAYPAL",
                    "payee_preferred": "IMMEDIATE_PAYMENT_REQUIRED"
                },
                "return_url": "http://localhost:8000/",
                "cancel_url": "http://localhost:8000/"
            }
        }""".replace('Email', email).replace('PlanId', plan_id).replace('TimeStart', t).encode('utf-8')
    response = requests.post(url, headers=headers, data=data).json()

    return response


def cancel_subscription(subscription_id):
    url = f'https://api-m.sandbox.paypal.com/v1/billing/subscriptions/{subscription_id}/cancel'
    headers = {'Authorization': 'Bearer ' + get_token(),
               'Content-Type': 'application/json',
               }
    data = '{"reason": "使用者要求取消訂閱"}'.encode('utf-8')
    response = requests.post(url, headers=headers, data=data)

    return response


def activate_subscription(subscription_id):
    url = f'https://api-m.sandbox.paypal.com/v1/billing/subscriptions/{subscription_id}/activate'
    headers = {'Authorization': 'Bearer ' + get_token(),
               'Content-Type': 'application/json',
               }
    data = '{"reason": "使用者要求激活訂閱"}'.encode('utf-8')
    response = requests.post(url, headers=headers, data=data)

    return response


def suspend_subscription(subscription_id):
    url = f'https://api-m.sandbox.paypal.com/v1/billing/subscriptions/{subscription_id}/suspend'
    headers = {'Authorization': 'Bearer ' + get_token(),
               'Content-Type': 'application/json',
               }
    data = '{"reason": "使用者要求暫停訂閱"}'.encode('utf-8')
    response = requests.post(url, headers=headers, data=data)

    return response


def subscription_revise(subscriptions_id, email, plan_id):
    url = f'https://api-m.sandbox.paypal.com/v1/billing/subscriptions/{subscriptions_id}/revise'
    headers = {
        'Authorization': 'Bearer ' + get_token(),
        'Content-Type': 'application/json',
        'PayPal-Request-Id': 'SUBSCRIPTION-TEST-001',
        'Prefer': 'return=representation',
    }
    
    t = (datetime.now(timezone(timedelta(hours=+0))) + timedelta(minutes=0)).isoformat(timespec="seconds").split('+')[0] + "Z"
    data = """{
            "plan_id": "PlanId",
            "start_time": "TimeStart",
            "quantity": "1",
            "shipping_amount": {
                "currency_code": "TWD",
                "value": "0"
            },
            "subscriber": {
                "name": {
                    "given_name": "",
                    "surname": ""
                },
                "email_address": "Email",
                "shipping_address": {
                    "name": {
                        "full_name": ""
                    },
                    "address": {
                        "address_line_1": "",
                        "address_line_2": "",
                        "admin_area_2": "",
                        "admin_area_1": "",
                        "postal_code": "",
                        "country_code": "TW"
                    }
                }
            },
            "application_context": {
                "brand_name": "INVESTLN 關連投資",
                "locale": "zh-TW",
                "shipping_preference": "SET_PROVIDED_ADDRESS",
                "user_action": "SUBSCRIBE_NOW",
                "payment_method": {
                    "payer_selected": "PAYPAL",
                    "payee_preferred": "IMMEDIATE_PAYMENT_REQUIRED"
                },
                "return_url": "http://localhost:8000/",
                "cancel_url": "http://localhost:8000/"
            }
        }""".replace('Email', email).replace('PlanId', plan_id).replace('TimeStart', t).encode('utf-8')
    response = requests.post(url, headers=headers, data=data).json()

    return response