from django.db import models

SUBSCRIPTION_MODE_CHOICES = [
    ('free', '免費版'),
    ('pro', '專業版'),
    ('pro+', '專業加強版'),
]

# Create your models here.
class Subscription(models.Model):
    start_time = models.DateTimeField(blank=True, null=True)
    username = models.CharField(max_length=170)
    status = models.CharField(max_length=20, choices=SUBSCRIPTION_MODE_CHOICES)
    plan_id = models.CharField(max_length=170, blank=True, null=True)
    subscription_id = models.CharField(max_length=170, blank=True, null=True)
    subscription_status = models.CharField(max_length=170, blank=True, null=True)
    free_trial = models.IntegerField(default=1)