from django.urls import reverse
from django.shortcuts import render, redirect
from pay.models import Subscription
from . import pay

def pricing(request):
    if request.user.is_active:
        user = request.user
        subscription = Subscription.objects.get(username=user.username)
        return render(request, 'pricing_free_free.html', {'status': subscription.status, 'free_trial': subscription.free_trial})
    
    return render(request, 'pricing_free_free.html')

def pro_subscription_create(request):
    if request.user.is_active:
        user = request.user
        email = user.email
        subscription = Subscription.objects.get(username=user.username)

        if subscription.status == 'free':
            if subscription.free_trial == 0:
                plan_id = 'P-66J57143M1770721NMSKDOTI'
            else:
                plan_id = 'P-9LX64487FB623871RMSE5JYA'

            order = pay.create_subscription(email=email, plan_id=plan_id)
            print(order)
            
            subscription.plan_id = order['plan_id']
            subscription.subscription_id = order['id']
            subscription.subscription_status = order['status']
            subscription.start_time = order['start_time']
            subscription.save()
            
            link = order['links'][0]['href']
            return redirect(link)
        else:
            return redirect('pricing')


    else:
        continue_url = reverse('login')
        return redirect(f'{continue_url}?continue=pro_subscription_create')
    

def pro_plus_subscription_create(request):
    if request.user.is_active:
        user = request.user
        email = user.email
        subscription = Subscription.objects.get(username=user.username)

        if subscription.status == 'free':
            if subscription.free_trial == 0:
                plan_id = 'P-7SK227180Y3213809MSKSYBA'
            else:
                plan_id = 'P-55C94932DY368001HMSKR5PQ'

            order = pay.create_subscription(email=email, plan_id=plan_id)
            print(order)
            subscription.subscription_id = order['id']
            subscription.start_time = order['start_time']
            subscription.save()
            link = order['links'][0]['href']
            return redirect(link)
        else:
            return redirect('pricing')


    else:
        continue_url = reverse('login')
        return redirect(f'{continue_url}?continue=pro_plus_subscription_create')

def revise_to_pro_plus_subscription(request):
    pass

def revise_to_pro_subscription(request):
    pass

def subscription_cancel(request):
    if request.user.is_active:
        user = request.user
        email = user.email
        subscription = Subscription.objects.get(username=user.username)
        subscription_cancel = pay.cancel_subscription(subscription.subscription_id)
        subscription.status = 'free'
        subscription.save()
        print(subscription_cancel)

    return redirect('pricing')


def subscription_verify(request):
    request.GET.get('')