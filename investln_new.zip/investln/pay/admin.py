from django.contrib import admin
from .models import Subscription

# Register your models here.
class SubscriptionAdmin(admin.ModelAdmin):
    list_display = ('username', 'status', 'plan_id', 'subscription_id', 'subscription_status', 'start_time', 'free_trial')

admin.site.register(Subscription, SubscriptionAdmin)