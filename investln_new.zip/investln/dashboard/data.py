import pandas as pd
from urllib import parse
import sqlite3

conn = sqlite3.connect('./investln/dashboard/investln_database.db')  #建立資料庫
cursor = conn.cursor() # 建立鼠標

for get in ['公司基本資料', '估值', '營收', '盈餘', '淨值', '負債', '股利']:
    get_url =  parse.quote(get)
    data = pd.read_json(f'https://script.google.com/macros/s/AKfycbxkrdww19SQM2rVBxk2bF7mo8w7difk7adHybLmthSoukZds3YlVWyCOgCUxvcevkSD/exec?name={get_url}')

    data.columns =  data.iloc[0]

    if data.iloc[0, 0] == '#ERROR!':
        data.iloc[0, 0] = '代號'

    data = data.drop(0, axis=0).rename_axis(None, axis=1).reset_index(drop=True)

    print(data)

    data.to_sql(get, conn, if_exists='replace')
"""

search = '"2303"'

cursor.execute(f'SELECT * FROM 公司基本資料 WHERE 代號 = {search}')
result = cursor.fetchall()
if result == []:
    cursor.execute(f'SELECT * FROM 公司基本資料 WHERE 公司 = {search}')
    result = cursor.fetchall()

if result == []:
    print('無資料')
else:
    result = result[0]
    if len(result) > 17:
        result = result[1:]

    columns = [desc[0] for desc in cursor.description][1:]
    dic = dict(zip(columns, result))
    print(dic)
"""