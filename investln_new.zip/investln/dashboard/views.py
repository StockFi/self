from django.shortcuts import render
from pay.models import Subscription
from django.http import HttpResponse
from django.conf import settings
import threading
import sqlite3
import pandas as pd

Sitemap_dt = []

def SitemapData():
    conn = sqlite3.connect('./dashboard/investln_database.db')  #建立資料庫
    d = pd.read_sql("SELECT * FROM 估值", conn)
    d_n = d['代號']
    Sitemap_dt.clear()
    Sitemap_dt.append(f"{settings.WEB_DOMAIN_URL}")
    Sitemap_dt.append(f"{settings.WEB_DOMAIN_URL}/robots.txt")
    Sitemap_dt.append(f"{settings.WEB_DOMAIN_URL}/ads.txt")
    Sitemap_dt.append(f"{settings.WEB_DOMAIN_URL}/sitemap.txt")
    Sitemap_dt.append(f"{settings.WEB_DOMAIN_URL}/")
    Sitemap_dt.append(f"{settings.WEB_DOMAIN_URL}/#about")
    Sitemap_dt.append(f"{settings.WEB_DOMAIN_URL}/#call")
    Sitemap_dt.append(f"{settings.WEB_DOMAIN_URL}/pricing/")
    Sitemap_dt.append(f"{settings.WEB_DOMAIN_URL}/account/auth/login/")
    Sitemap_dt.append(f"{settings.WEB_DOMAIN_URL}/account/auth/signup/")
    Sitemap_dt.append(f"{settings.WEB_DOMAIN_URL}/account/auth/logout/")
    Sitemap_dt.append(f"{settings.WEB_DOMAIN_URL}/account/auth/forgetPassword/")
    Sitemap_dt.append(f"{settings.WEB_DOMAIN_URL}/account/auth/forgetPassword/")
    for i in d_n:
        Sitemap_dt.append(f"{settings.WEB_DOMAIN_URL}/valuation/?ticker={i}")
        Sitemap_dt.append(f"{settings.WEB_DOMAIN_URL}/revenue/?ticker={i}")
        Sitemap_dt.append(f"{settings.WEB_DOMAIN_URL}/eps/?ticker={i}")
        Sitemap_dt.append(f"{settings.WEB_DOMAIN_URL}/bvps/?ticker={i}")
        Sitemap_dt.append(f"{settings.WEB_DOMAIN_URL}/debt/?ticker={i}")
        Sitemap_dt.append(f"{settings.WEB_DOMAIN_URL}/dividend/?ticker={i}")

def SitemapView(request):
    thread = threading.Thread(target=SitemapData, args=())
    thread.start()
    thread.join()
    return HttpResponse("\n".join(Sitemap_dt), content_type="text/plain")

ret_values = []

def search(ticker, item):
    # 資料庫連線
    conn = sqlite3.connect('./dashboard/investln_database.db')  #建立資料庫
    cursor = conn.cursor() # 建立鼠標

    ret_values.clear() # 清空全域變數
    output = {} # 最終回應變數
    for i in item:
        cursor.execute(f'SELECT * FROM {i} WHERE 代號 = ?', (ticker,))
        result = cursor.fetchall()
        if result != []:
            result = result[0]
            columns = [desc[0] for desc in cursor.description]
            dic = dict(zip(columns, result))
            output.update(dic)
    
    ret_values.append(output)
    conn.close()


def valuation(request):
    ticker = request.GET.get('ticker')
    items = ['公司基本資料', '估值']

    thread = threading.Thread(target=search, args=(ticker, items))
    thread.start()
    thread.join()
    result = ret_values[0]
    result = {key.replace('(', '').replace(')', '').replace('%', ''): value for key, value in result.items()}

    if result == {}:
        context = {'error_info': '股票代號輸入錯誤，或無此資料。'}
        thread = threading.Thread(target=search, args=('1101', items))
        thread.start()
        thread.join()
        result = ret_values[0]
        result = {key.replace('(', '').replace(')', '').replace('%', ''): value for key, value in result.items()}
    else:
        context = {'error_info': ''}

    context.update(result)

    try:
        context['成立日期'] = context['成立日期'].split('T')[0]
    except:
        pass

    if request.user.is_active:
        user = request.user
        subscription = Subscription.objects.get(username=user.username)
        context.update({'status': subscription.status})

        return render(request, 'dashboard/valuation_free.html', context)

    context.update({'status': None})
    return render(request, 'dashboard/valuation_free.html', context)


def revenue(request):
    ticker = request.GET.get('ticker')
    items = ['營收']

    thread = threading.Thread(target=search, args=(ticker, items))
    thread.start()
    thread.join()
    result = ret_values[0]
    result = {key.replace('(', '').replace(')', '').replace('%', '').replace('-', ''): value for key, value in result.items()}

    if result == {}:
        context = {'error_info': '股票代號輸入錯誤，或無此資料。'}
        thread = threading.Thread(target=search, args=('1101', items))
        thread.start()
        thread.join()
        result = ret_values[0]
        result = {key.replace('(', '').replace(')', '').replace('%', '').replace('-', ''): value for key, value in result.items()}
    else:
        context = {'error_info': ''}

    context.update(result)

    if request.user.is_active:
        user = request.user
        subscription = Subscription.objects.get(username=user.username)
        context.update({'status': subscription.status})

        return render(request, 'dashboard/revenue.html', context)

    context.update({'status': None})
    return render(request, 'dashboard/revenue.html', context)


def eps(request):
    ticker = request.GET.get('ticker')
    items = ['盈餘']

    thread = threading.Thread(target=search, args=(ticker, items))
    thread.start()
    thread.join()
    result = ret_values[0]
    result = {key.replace('(', '').replace(')', '').replace('%', '').replace('-', ''): value for key, value in result.items()}

    if result == {}:
        context = {'error_info': '股票代號輸入錯誤，或無此資料。'}
        thread = threading.Thread(target=search, args=('1101', items))
        thread.start()
        thread.join()
        result = ret_values[0]
        result = {key.replace('(', '').replace(')', '').replace('%', '').replace('-', ''): value for key, value in result.items()}
    else:
        context = {'error_info': ''}

    context.update(result)

    if request.user.is_active:
        user = request.user
        subscription = Subscription.objects.get(username=user.username)
        context.update({'status': subscription.status})

        return render(request, 'dashboard/eps.html', context)

    context.update({'status': None})
    return render(request, 'dashboard/eps.html', context)


def bvps(request):
    ticker = request.GET.get('ticker')
    items = ['淨值']

    thread = threading.Thread(target=search, args=(ticker, items))
    thread.start()
    thread.join()
    result = ret_values[0]
    result = {key.replace('(', '').replace(')', '').replace('%', '').replace('-', ''): value for key, value in result.items()}

    if result == {}:
        context = {'error_info': '股票代號輸入錯誤，或無此資料。'}
        thread = threading.Thread(target=search, args=('1101', items))
        thread.start()
        thread.join()
        result = ret_values[0]
        result = {key.replace('(', '').replace(')', '').replace('%', '').replace('-', ''): value for key, value in result.items()}
    else:
        context = {'error_info': ''}

    context.update(result)

    if request.user.is_active:
        user = request.user
        subscription = Subscription.objects.get(username=user.username)
        context.update({'status': subscription.status})

        return render(request, 'dashboard/bvps.html', context)

    context.update({'status': None})
    return render(request, 'dashboard/bvps.html', context)


def debt(request):
    ticker = request.GET.get('ticker')
    items = ['負債']

    thread = threading.Thread(target=search, args=(ticker, items))
    thread.start()
    thread.join()
    result = ret_values[0]
    result = {key.replace('(', '').replace(')', '').replace('%', '').replace('-', ''): value for key, value in result.items()}

    if result == {}:
        context = {'error_info': '股票代號輸入錯誤，或無此資料。'}
        thread = threading.Thread(target=search, args=('1101', items))
        thread.start()
        thread.join()
        result = ret_values[0]
        result = {key.replace('(', '').replace(')', '').replace('%', '').replace('-', ''): value for key, value in result.items()}
    else:
        context = {'error_info': ''}

    context.update(result)

    if request.user.is_active:
        user = request.user
        subscription = Subscription.objects.get(username=user.username)
        context.update({'status': subscription.status})

        return render(request, 'dashboard/debt.html', context)

    context.update({'status': None})
    return render(request, 'dashboard/debt.html', context)


def dividend(request):
    ticker = request.GET.get('ticker')
    items = ['股利']

    thread = threading.Thread(target=search, args=(ticker, items))
    thread.start()
    thread.join()
    result = ret_values[0]
    result = {key.replace('(', '').replace(')', '').replace('%', '').replace('-', ''): value for key, value in result.items()}

    if result == {}:
        context = {'error_info': '股票代號輸入錯誤，或無此資料。'}
        thread = threading.Thread(target=search, args=('1101', items))
        thread.start()
        thread.join()
        result = ret_values[0]
        result = {key.replace('(', '').replace(')', '').replace('%', '').replace('-', ''): value for key, value in result.items()}
    else:
        context = {'error_info': ''}

    context.update(result)

    if request.user.is_active:
        user = request.user
        subscription = Subscription.objects.get(username=user.username)
        context.update({'status': subscription.status})

        return render(request, 'dashboard/dividend.html', context)

    context.update({'status': None})
    return render(request, 'dashboard/dividend.html', context)