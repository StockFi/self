from django.shortcuts import render, redirect
from django.utils.crypto import get_random_string
from django.template.loader import render_to_string
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.hashers import check_password
from django.views.decorators.cache import never_cache # 禁用暫存
from django.contrib.auth.models import User
from django.core.mail import EmailMessage
from account.models import EmailVerify
from pay.models import Subscription
from django.conf import settings
from django.urls import reverse
import threading
import time


def user_signup(request):
    if request.user.is_active:
        return redirect('/')
    
    if request.method == 'POST':
        email = request.POST.get('email').lower()
    
        if not email:
            return render(request, 'account/signup.html', {'error': '請輸入電子郵件'})
        
        elif email.split('@')[1] in ['zbock.com', 'zslsz.com', 'omeie.com', 'nezid.com', 'chodyi.com', 'vhoff.com', 'backva.com', 'bagonew.com', 'avidapro.com', 'blondmail.com', 'givmail.com', 'chapsmail.com', 'temptami.com', 'fivermail.com', 'replyloop.com', 'tupmail.com', 'getnada.com', 'spicysoda.com', 'tafmail.com', 'clowmail.com', 'vomoto.com', 'getmule.com', 'fivermail.com', 'guysmail.com', 'robot-mail.com', 'guysmail.com', 'blondmail.com', 'dropjar.com', 'gimpmail.com', 'inboxbear.com', 'getairmail.com', 'mymaily.lol', 'wemel.site', 'wemel.top', 'mywrld.top', 'containzof.com', 'yopmail.com', 'meidecn.com', 'maildrop.cc', 'cwmxc.com', 'cazlq.com', 'cazlv.com', 'ckptr.com']:
            return render(request, 'account/signup.html', {'error': '請避免使用一次性電子郵件'})
        
        username = email.split('@')[0].split('+')[0].replace('.', '') + "@" + email.split("@")[1]
        
        if User.objects.filter(username=username, is_active=True).exists():
            return render(request, 'account/signup.html', {'error': '該帳號已存在'})
        
        elif EmailVerify.objects.filter(username=username).exists():
            token = EmailVerify.objects.get(username=username)
            registration_time = int(token.time.timestamp())
            elapsed_time = int(time.time() - registration_time)
            if elapsed_time < 30:
                return render(request, 'account/signup.html', {'error': f'請於{30 - elapsed_time}秒後再次嘗試'})
            else:
                token.delete()
        
        token_value = get_random_string(length=45)
        token = EmailVerify(mode='signup', token=token_value, email=email, username=username)
        token.save()

        # 電子郵件驗證連結
        verification_link = f"{settings.WEB_DOMAIN_URL}/account/auth/emailVerify/?token={token_value}"

        # 渲染HTML模板
        email_template = render_to_string(
            'account/email/signup_email.html',
            {'verification_link': verification_link}
        )

        email_message = EmailMessage(
            '驗證您的信箱',  # 電子郵件標題
            email_template,  # 電子郵件內容
            settings.EMAIL_HOST_USER,  # 寄件者
            [email]  # 收件者
        )
        email_message.content_subtype = 'html'

        email_message.fail_silently = False

        email_message.send()

        context_success = {
            'title': '註冊',
            'state': '發送成功! ',
            'state_info': '請點擊郵件連結',
            'info': '請於15分鐘內點擊郵件連結激活帳戶，如果您未收到，請檢查「垃圾郵件」。',
        }

        return render(request, 'account/info.html', context_success)
    
    return render(request, 'account/signup.html', {'error': '請輸入電子郵件'})


def user_login(request):
    continue_url = request.GET.get('continue', '/')
    
    if request.user.is_active:
        return redirect(continue_url)

    if request.method == 'POST':
        email = request.POST.get('email').lower()
        username = email.split('@')[0].split('+')[0].replace('.', '') + "@" + email.split("@")[1]
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)

        if user is not None and user.is_active:
            login(request, user)
            return redirect(continue_url)

        return render(request, 'account/login.html', {'error': '帳號或密碼錯誤'})

    return render(request, 'account/login.html')


def user_logout(request):
    logout(request)
    return redirect('/')


def email_verify(request):
    context_success = {
        'title': '密碼',
        'state': '設定成功!',
        'state_info': '請重新登入',
        'info': '使用者密碼設定成功。',
    }
    context_fail = {
        'title': '驗證',
        'state': '驗證失敗!',
        'state_info': '連結失效',
        'info': '連結地址錯誤或超時，請重操作。',
    }
    token_data = request.GET.get('token')

    try:
        token = EmailVerify.objects.get(token=token_data)
    except EmailVerify.DoesNotExist:
        return render(request, 'account/info.html', context_fail)

    mode = token.mode
    elapsed_time = time.time() - token.time.timestamp()

    if elapsed_time > 900:
        return render(request, 'account/info.html', context_fail)

    if mode in ['signup', 'forgetPassword'] and request.method == 'POST':
        password = request.POST.get('password')
        password_repeat = request.POST.get('password_repeat')

        if password == password_repeat and len(password) >= 8:
            try:
                user = User.objects.get(username=token.username)
                user.set_password(password)
                user.save()
                token.delete()
            except User.DoesNotExist:
                user = User.objects.create_user(username=token.username, email=token.email, password=password)
                subscription = Subscription.objects.create(username=token.username, status='pro')
                token.delete()

                ### 傳送邀請加入社群訊息
                # 渲染HTML模板
                email_template = render_to_string(
                    'account/email/welcome.html',
                )

                email_message = EmailMessage(
                    'INVESTLN & 關聯投資 誠摯邀請您一同加入我們的社群!',  # 電子郵件標題
                    email_template,  # 電子郵件內容
                    settings.EMAIL_HOST_USER,  # 寄件者
                    [token.email]  # 收件者
                )
                email_message.content_subtype = 'html'

                email_message.fail_silently = False
                email_message.send()

            return render(request, 'account/info.html', context_success)

    return render(request, 'account/set_password.html')


def forget_password(request):
    if request.user.is_active:
        return redirect('/')
    
    context_success = {
        'title': '重設密碼',
        'state': '傳送成功! ',
        'state_info': '請點擊郵件連結',
        'info': '請於15分鐘內點擊郵件連結，即可完成密碼變更。',
    }

    if request.method == 'POST':
        email = request.POST['email'].lower()
        username = email.split('@')[0].split('+')[0].replace('.', '') + "@" + email.split("@")[1]
    
        if User.objects.filter(username=username, is_active=True).exists():
            if EmailVerify.objects.filter(username=username).exists():
                token = EmailVerify.objects.get(username=username)
                registration_time = int(token.time.timestamp())
                elapsed_time = int(time.time() - registration_time)
                if elapsed_time < 30:
                    return render(request, 'account/forget_password.html', {'error': f'請於{30 - elapsed_time}秒後再次嘗試'})
                else:
                    token.delete()
            
            token_value = get_random_string(length=45)
            token = EmailVerify(mode='forgetPassword', token=token_value, email=email, username=username)
            token.save()

            # 電子郵件驗證連結
            verification_link = f"{settings.WEB_DOMAIN_URL}/account/auth/emailVerify/?token={token_value}"

            # 渲染HTML模板
            email_template = render_to_string(
                'account/email/forget_password_email.html',
                {'verification_link': verification_link}
            )

            email_message = EmailMessage(
                '重設密碼',  # 電子郵件標題
                email_template,  # 電子郵件內容
                settings.EMAIL_HOST_USER,  # 寄件者
                [email]  # 收件者
            )
            email_message.content_subtype = 'html'
            
            email_message.fail_silently = False
            email_message.send()

            return render(request, 'account/info.html', context_success)

        return render(request, 'account/info.html', context_success)

    return render(request, 'account/forget_password.html')


@never_cache
def account(request):
    if not request.user.is_active:
        continue_url = reverse('login')
        return redirect(f'{continue_url}?continue=account')
    
    user = request.user
    email = user.email
    last_name = user.last_name
    first_name = user.first_name
    last_login = user.last_login
    date_joined = user.date_joined

    subscription = Subscription.objects.get(username=user.username)
    subscription_state = subscription.status
    subscription_start_time = subscription.start_time

    context = {
        'email': email,
        'last_name': last_name,
        'first_name': first_name,
        'last_login': last_login,
        'date_joined': date_joined,
        'subscription_state': subscription_state,
        'subscription_start_time': subscription_start_time,
    }

    if request.method == 'POST':
        password = request.POST.get('password')
        new_password = request.POST.get('newPassword')
        
        if not check_password(password, user.password):
            context['info_password'] = '密碼錯誤'
        elif len(new_password) < 8:
            context['info_password'] = '新密碼格式錯誤'
        else:
            user.set_password(new_password)
            user.save()
            context_success = {
                'title': '密碼',
                'state': '變更成功!',
                'state_info': '請重新登入。',
                'info': '使用者密碼變更成功',
            }
            return render(request, 'account/info.html', context_success)

    return render(request, 'account/account.html', context)

def change_name(request):
    user = request.user
    last_name = request.POST.get('last_name')
    first_name = request.POST.get('first_name')
    user.last_name = last_name
    user.first_name = first_name
    user.save()
    return redirect('account')