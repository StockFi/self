from django.contrib import admin
from .models import EmailVerify

class EmailVerifyAdmin(admin.ModelAdmin):
    list_display = ('time', 'mode', 'token', 'email', 'username')

admin.site.register(EmailVerify, EmailVerifyAdmin)
