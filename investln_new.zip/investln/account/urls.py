from django.urls import path
from . import views

urlpatterns = [
    path('', views.account, name='account'),
    path('change/name/', views.change_name, name='change_name'),
    path('auth/login/', views.user_login, name='login'),
    path('auth/logout/', views.user_logout, name='logout'),
    path('auth/signup/', views.user_signup, name='signup'),
    path('auth/emailVerify/', views.email_verify, name='emailVerify'),
    path('auth/forgetPassword/', views.forget_password, name='forgetPassword'),
]