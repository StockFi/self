from django.db import models
from django.utils.crypto import get_random_string

EMAILVERIFY_MODE_CHOICES = [
    ('signup', 'Sign Up'),
    ('forgetPassword', 'Forget Password'),
]


# Create your models here.
class EmailVerify(models.Model):
    time = models.DateTimeField(auto_now_add=True)
    mode = models.CharField(max_length=20, choices=EMAILVERIFY_MODE_CHOICES)
    token = models.CharField(max_length=100, unique=True, blank=True, null=False)
    email = models.EmailField(max_length=170, unique=True)
    username = models.CharField(max_length=170, unique=True)
    def save(self, *args, **kwargs):
        if not self.token:
            self.token = get_random_string(length=45)
        super().save(*args, **kwargs)
